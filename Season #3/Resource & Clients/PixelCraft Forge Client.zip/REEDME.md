The PixelCraft Forge Client is a zip file that holds the following folders that must be placed into your game instance
 - config
 - mods
those folders need to be placed into were ever your game stores its data you also need to make sure that forge 28.1.60 or newer is installed